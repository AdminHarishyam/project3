﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace E_STAMP_AND_E_SIGN.E_STAMP
{
    public partial class E_stamp_template_mstr : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["userid"] = "90766";
            Session["USER_NM"] = "SALINI P";
        }

        public class eStamp_list
        {
            public int state_id { get; set; }
            public int select_count { get; set; }
            public int stamp_paper { get; set; }
            public int tbl_id { get; set; }
            public string state_name { get; set; }
            public string state_nm { get; set; }
            public string Temp_name { get; set; }
            public string stamptag { get; set; }
            public string file_name { get; set; }
            public int tbl_stateId { get; set; }
            

        }
        [WebMethod]
        public static IList eStamp_stateListdb()
        {
            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            //int COMP_ID = Convert.ToInt32(HttpContext.Current.Session["CompId"].ToString());
            DataTable Dts = new DataTable();
            Dts = servcon.eStamp_states_selection("1");
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    state_list.Add(new eStamp_list()
                    {
                        state_id = Convert.ToInt32(Dts.Rows[j]["state_id"]),
                        state_name = Convert.ToString(Dts.Rows[j]["state_name"]),
                    });
                }
            }
            return state_list;
        }

        [WebMethod]
        public static string eStamp_insert_template_db(string STATE_ID, string TEMPLATE_ID, string FLAG_ID, string STAMP_TAG,string file_nme)
        {

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
           // int COMP_ID = 0;
            string USER_ID = HttpContext.Current.Session["userid"].ToString();
            //string USER_NM = HttpContext.Current.Session["USER_NM"].ToString();
            string Dts = servcon.eStamp_insert_template(STATE_ID, TEMPLATE_ID, STATE_ID,FLAG_ID, STAMP_TAG, file_nme);
            return Dts;
        }

        [WebMethod]
        public static IList eStamp_fetch_TEMPDetails_db(string STATE_ID)
        {
            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string user_id = HttpContext.Current.Session["userid"].ToString();
            DataTable Dts = new DataTable();
            Dts = servcon.eStamp_fetch_TEMPDetails(STATE_ID);
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    state_list.Add(new eStamp_list()
                    {
                        state_name = Convert.ToString(Dts.Rows[j]["state_name"]),
                        Temp_name = Convert.ToString(Dts.Rows[j]["template_id"]),
                        stamptag = Convert.ToString(Dts.Rows[j]["stamp_tag"]),
                        file_name = Convert.ToString(Dts.Rows[j]["template_name"]),
                        tbl_id = Convert.ToInt32(Dts.Rows[j]["tab_id"]),
                        tbl_stateId= Convert.ToInt32(Dts.Rows[j]["state_id"]),

                    });
                }
            }
            return state_list;
        }

        [WebMethod]
        public static string eStamp_delete_temp_db(int tbl_id)
        {

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string user_id = HttpContext.Current.Session["userid"].ToString();
            string Dts = servcon.eStamp_delete_temp(tbl_id);
            return Dts;
        }
    }
}