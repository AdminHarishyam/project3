﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace E_STAMP_AND_E_SIGN.E_STAMP
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public class eStamp_list
        {
          
            public string datalist_1 { get; set; }
       


        }
        [WebMethod]
        public static string eStamp_generate()
        { 
            var client = new RestClient("https://ext.digio.in:444");

            var request = new RestRequest("/v2/client/template/multi_templates/create_sign_request", Method.Post);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", "Basic QUlQSTI4UjhQRDNROTlUVkM0NlNSMUZWRFZGQjRFR1U6WlhJT1NDWFJVQldJWDdWVUdVNUtPN0NNTDJaRUFCTFk=");
            var body = @"{" + "\n" +
            @"    ""signers"": [" + "\n" +
            @"        {" + "\n" +
            @"            ""identifier"": ""jithinkarookaran@gmail.com""," + "\n" +
            @"            ""name"": ""jithin k J""," + "\n" +
            @"            ""sign_type"": ""Aadhaar""" + "\n" +
            @"        }," + "\n" +
            @"        {" + "\n" +
            @"            ""identifier"": ""lakshmicp68@gmail.com""," + "\n" +
            @"            ""name"": ""Sreelakshmi.C P""," + "\n" +
            @"            ""sign_type"": ""Aadhaar""" + "\n" +
            @"        }" + "\n" +
            @"    ]," + "\n" +
            @"    ""expire_in_days"": 10," + "\n" +
            @"    ""send_sign_link"": true," + "\n" +
            @"    ""notify_signers"": true," + "\n" +
            @"    ""display_on_page"": ""custom""," + "\n" +
            @"    ""sign_coordinates"": {" + "\n" +
            @"        ""jithinkarookaran@gmail.com"": {" + "\n" +
            @"            ""1"": [" + "\n" +
            @"                {" + "\n" +
            @"                    ""llx"": 374.03379055441474," + "\n" +
            @"                    ""lly"": 325.35158283648883," + "\n" +
            @"                    ""urx"": 514.0316226500211," + "\n" +
            @"                    ""ury"": 365.3484905660377" + "\n" +
            @"                }" + "\n" +
            @"            ]" + "\n" +
            @"        }," + "\n" +
            @"        ""lakshmicp68@gmail.com"": {" + "\n" +
            @"            ""1"": [" + "\n" +
            @"                {" + "\n" +
            @"                    ""llx"": 388.7017823408624," + "\n" +
            @"                    ""lly"": 251.42655380891264," + "\n" +
            @"                    ""urx"": 528.6996144364688," + "\n" +
            @"                    ""ury"": 291.42346153846154" + "\n" +
            @"                }" + "\n" +
            @"            ]" + "\n" +
            @"        }" + "\n" +
            @"    }," + "\n" +
            @"    ""file_name"": ""a4-size-portrait.pdf""," + "\n" +
            @"    ""estamp_request"": {" + "\n" +
            @"        ""tags"": {" + "\n" +
            @"            ""KL-100-"": 1" + "\n" +
            @"        }," + "\n" +
            @"        ""sign_on_page"": ""LAST""," + "\n" +
            @"        ""note_content"": ""This is dummy content""," + "\n" +
            @"        ""note_on_page"": ""ALL""" + "\n" +
            @"    }," + "\n" +
            @"    ""callback"": ""7e373aa0-a409-6f58-be4e-58ead2f6ba339""," + "\n" +
            @"    ""templates"": [" + "\n" +
            @"        {" + "\n" +
            @"            ""template_key"": ""TMP221031131152497GRNAUKTHD6YQXV""," + "\n" +
            @"            ""template_values"": {" + "\n" +
            @"                ""NAME"": ""JITHIN K J""," + "\n" +
            @"                ""MOB"": ""9995982483""" + "\n" +
            @"            }" + "\n" +
            @"         } ]" + "\n" +
            @"        " + "\n" +
            @" }" + "\n" +
            @"" + "\n" +
            @"";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            string dataString = response.Content;


            string jsonString = string.Empty;
            jsonString = JsonConvert.SerializeObject(response);
            return jsonString;


            // return JsonConvert.DeserializeObject(dataString);

            //eStamp_list ci = new eStamp_list();
            //List<eStamp_list> state_list = new List<eStamp_list>();

            //dynamic jResults = JsonConvert.DeserializeObject(dataString);
            //List<string> counties = new List<string>();
            //foreach (var county in jResults.Everything)
            //{
            //    counties.Add((string)county.datalist_1);
            //}
            //return counties;

            //return jResults;

        }
       
    }
}