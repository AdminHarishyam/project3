﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace E_STAMP_AND_E_SIGN.E_STAMP
{
    public partial class Stamp_selection : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty){

            //}
            Session["userid"] = "345778";
            Session["USER_NM"] = "TEST_USERuat";

        }
        public class eStamp_list
        {
            public int state_id { get; set; }
            public int select_count { get; set; }
            public int stamp_paper { get; set; }
            public int tbl_id { get; set; }
            public string state_name { get; set; }
            public string state_nm { get; set; }

            public string mob_no { get; set; }
            public string tempId { get; set; }
            public string stamp_tag { get; set; }
            public string dates { get; set; }
            public string emp_parent_nm { get; set; }
            public string age { get; set; }
            public string emp_address { get; set; }
            public string emp_post { get; set; }
            public string emp_district { get; set; }
            public string emp_state { get; set; }
            public string emp_pin { get; set; }
            public string sur1_name { get; set; }
            public string sur1_parent { get; set; }
            public string sur1_age { get; set; }
            public string sur1_address { get; set; }
            public string sur1_post { get; set; }
            public string sur1_district { get; set; }
            public string sur1_state { get; set; }
            public string sur2_name { get; set; }
            public string sur2_parent_nm { get; set; }
            public string sur2_age { get; set; }
            public string sur2_address { get; set; }
            public string sur2_post { get; set; }
            public string sur2_district { get; set; }
            public string sur2_state { get; set; }
            public string employee_name { get; set; }
            public string stateID { get; set; }



        }
        [WebMethod]
        public static IList eStamp_stateListdb()
        {
            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            //int COMP_ID = Convert.ToInt32(HttpContext.Current.Session["CompId"].ToString());
            DataTable Dts = new DataTable();
            Dts = servcon.eStamp_states_selection("1");
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    state_list.Add(new eStamp_list()
                    {
                        state_id = Convert.ToInt32(Dts.Rows[j]["state_id"]),
                        state_name = Convert.ToString(Dts.Rows[j]["state_name"]),
                    });
                }
            }
            return state_list;
        }
        [WebMethod]
        public static string eStamp_insert_trackDb(string STATE_ID, int STAMP_PPR, int SELECTED_CNT)
        {

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            int COMP_ID = 0;
            string USER_ID = HttpContext.Current.Session["userid"].ToString();
            string USER_NM = HttpContext.Current.Session["USER_NM"].ToString();
            string Dts = servcon.eStamp_insert_track(USER_ID, USER_NM, STATE_ID, STAMP_PPR, 0, SELECTED_CNT, COMP_ID);
            return Dts;
        }
        [WebMethod]
        public static IList eStamp_fetch_stampDetailsDb()
        {
            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string user_id = HttpContext.Current.Session["userid"].ToString();
            DataTable Dts = new DataTable();
            Dts = servcon.eStamp_fetch_stampDetails(user_id);
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    state_list.Add(new eStamp_list()
                    {
                        stamp_paper = Convert.ToInt32(Dts.Rows[j]["stamp_paper"]),
                        select_count = Convert.ToInt32(Dts.Rows[j]["selected_cnt"]),
                        state_nm = Convert.ToString(Dts.Rows[j]["state_name"]),
                        stateID = Convert.ToString(Dts.Rows[j]["state_name"]),
                        tbl_id = Convert.ToInt32(Dts.Rows[j]["tab_id"])

                    });
                }
            }
            return state_list;
        }
        [WebMethod]
        public static string eStamp_delete_trackDb(int tbl_id)
        {

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string user_id = HttpContext.Current.Session["userid"].ToString();
            string Dts = servcon.eStamp_delete_track(tbl_id, user_id);
            return Dts;
        }
        //----------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------

        //[WebMethod]
        //public static string Vehicledetails()
        //{
        //    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
        //    DataTable Dts = new DataTable();
        //    HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
        //    int CompID = Convert.ToInt32(HttpContext.Current.Session["CompId"].ToString());
        //    string user_id = HttpContext.Current.Session["usr_id"].ToString();
        //    Dts = servcon.eStamp_fetch_userDetails(user_id);

        //    //aws_api.ServiceClient servc = new aws_api.ServiceClient();


        //    if (Dts.Rows.Count > 0)
        //    {
        //        for (int j = 0; j < Dts.Rows.Count; j++)
        //        {


        //            foreach (DataRow row in Dts.Rows)
        //            {
        //                //need to set value to NewColumn column
        //                row["emailId"] = emp_email;
        //                row["PHONE NUMBER"] = cont_phone;
        //                // or set it to some other value
        //            }


        //        }
        //    }
        //    string jsonString = string.Empty;
        //    jsonString = JsonConvert.SerializeObject(Dts);
        //    return jsonString;

        //}
        //-----------------------------------
        [WebMethod]
        public static string eStamp_generate(string state_id)
        {

            //---------------------------------------------------------------------
            string tempId = "";
            string stamp_tag = "";
            string mob = "";
            string name = "";
            string emp_eMail = "";
            string surety_eMail = "";
            string dates = "";
            string emp_parent_nm = "";
            string age = "";
            string template_name = "";
            string emp_address = "";
            string emp_post = "";
            string emp_district = "";
            string emp_state = "";
            string emp_pin = "";
            string sur1_name = "";
            string sur1_parent = "";
            string sur1_age = "";
            string sur1_address = "";
            string sur1_post = "";
            string sur1_district = "";
            string sur1_state = "";
            string sur2_name = "";
            string sur2_parent_nm = "";
            string sur2_age = "";
            string sur2_address = "";
            string sur2_post = "";
            string sur2_district = "";
            string sur2_state = "";
            string surety2_eMail = "";
            //string employee_name = "";

            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            string sgnnamearray = "";
            string tempArray1 = "";
            string tempArray2 = "";
            string employeeArray = "";
            string suretyArray = "";
            string dataFields = "";
            int numberOfRecords = 0;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            DataSet dataSet = new DataSet();
            DataTable Dts = new DataTable();
            DataTable Dts1 = new DataTable();
            DataTable Dts2 = new DataTable();
            DataTable allList = new DataTable();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            string user_id = HttpContext.Current.Session["userid"].ToString();
            dataSet = servcon.eStamp_fetch_userDetails(user_id);
            Dts = dataSet.Tables[0];
            Dts1 = dataSet.Tables[1];
            DataTable DATABANK = new DataTable("DATABANK");
            DATABANK.Columns.Add("identifier", typeof(String));
            DATABANK.Columns.Add("name", typeof(String));
            DATABANK.Columns.Add("sign_type", typeof(String));
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    DATABANK.Rows.Add(new Object[] { Dts.Rows[j]["emp_email"], Dts.Rows[j]["emp_name"], "Aadhaar" });
                    mob = Dts.Rows[j]["cont_phone"].ToString();
                    name = Dts.Rows[j]["emp_name"].ToString();
                    emp_eMail = Dts.Rows[j]["emp_email"].ToString();
                    //surety_eMail= Dts.Rows[j]["surety_email"].ToString();
                    dates = Dts.Rows[j]["date_pick"].ToString();
                    emp_parent_nm = Dts.Rows[j]["surety_parent"].ToString();
                    age = Dts.Rows[j]["emg_email"].ToString();
                    emp_address = Dts.Rows[j]["perm_add1"].ToString();
                    emp_post = Dts.Rows[j]["emp_post"].ToString();
                    emp_district = Dts.Rows[j]["emp_district"].ToString();
                    emp_state = Dts.Rows[j]["emp_state"].ToString();
                    emp_pin = Dts.Rows[j]["perm_pin"].ToString();
                    numberOfRecords++;
                    //get_employee_details
                }
            }
            if (Dts1.Rows.Count > 0)
            {
                for (int k = 0; k < Dts1.Rows.Count; k++)
                {
                    DATABANK.Rows.Add(new Object[] { Dts1.Rows[k]["emg_email"], Dts1.Rows[k]["surety_name"], "Aadhaar" });
                    numberOfRecords++;
                    if (k == 0)
                    {
                        sur1_name = Dts1.Rows[k]["surety_name"].ToString();
                        sur1_parent = Dts1.Rows[k]["surety_parentnm"].ToString();
                        sur1_age = Dts1.Rows[k]["age"].ToString();
                        sur1_address = Dts1.Rows[k]["surety_addr"].ToString();
                        sur1_post = Dts1.Rows[k]["surety_pin"].ToString();
                        sur1_district = Dts1.Rows[k]["surety_district"].ToString();
                        sur1_state = Dts1.Rows[k]["surety_state"].ToString();
                        sur1_state = Dts1.Rows[k]["surety_email"].ToString();
                        //get_surety1_details

                    }
                    else if (k == 1)
                    {
                        sur2_name = Dts1.Rows[k]["surety_name"].ToString();
                        sur2_parent_nm = Dts1.Rows[k]["surety_parentnm"].ToString();
                        sur2_age = Dts1.Rows[k]["age"].ToString();
                        sur2_address = Dts1.Rows[k]["surety_addr"].ToString();
                        sur2_post = Dts1.Rows[k]["surety_pin"].ToString();
                        sur2_district = Dts1.Rows[k]["surety_district"].ToString();
                        sur2_state = Dts1.Rows[k]["surety_state"].ToString();
                        //get_surety2_details
                    }
                }
            }
            sgnnamearray = JsonConvert.SerializeObject(DATABANK);
            Dts2 = servcon.eStamp_fetch_templateId(state_id);
            if (Dts2.Rows.Count > 0)
            {
                for (int l = 0; l < Dts2.Rows.Count; l++)
                {

                    tempId = Convert.ToString(Dts2.Rows[l]["template_id"]);
                    stamp_tag = Convert.ToString(Dts2.Rows[l]["stamp_tag"]);
                    template_name = Convert.ToString(Dts2.Rows[l]["template_name"]);
                    //get_template_details
                }

            }
            //-----------------------------------------------------
            DataTable DATABANK1 = new DataTable("DATABANK");
            DATABANK1.Columns.Add("date", typeof(String));
            DATABANK1.Columns.Add("emp_name", typeof(String));
            DATABANK1.Columns.Add("emp_parent/mother_name", typeof(String));
            DATABANK1.Columns.Add("emp_AGE", typeof(String));
            DATABANK1.Columns.Add("emp_Address", typeof(String));
            DATABANK1.Columns.Add("emp_post", typeof(String));
            DATABANK1.Columns.Add("emp_district", typeof(String));
            DATABANK1.Columns.Add("emp_state", typeof(String));
            DATABANK1.Columns.Add("emp_pin", typeof(String));

            ///
            allList.Columns.Add("date", typeof(String));
            allList.Columns.Add("emp_name", typeof(String));
            allList.Columns.Add("emp_parent/mother_name", typeof(String));
            allList.Columns.Add("emp_AGE", typeof(String));
            allList.Columns.Add("emp_Address", typeof(String));
            allList.Columns.Add("emp_post", typeof(String));
            allList.Columns.Add("emp_district", typeof(String));
            allList.Columns.Add("emp_state", typeof(String));
            allList.Columns.Add("emp_pin", typeof(String));
            //
            allList.Columns.Add("Surety2_name", typeof(String));
            allList.Columns.Add("Surety2_parent_name", typeof(String));
            allList.Columns.Add("Surety2_age", typeof(String));
            allList.Columns.Add("Surety2_address", typeof(String));
            allList.Columns.Add("Surety2_post", typeof(String));
            allList.Columns.Add("Surety2_district", typeof(String));
            allList.Columns.Add("Surety2_state", typeof(String));


            //
            allList.Rows.Add(new Object[] { /*Dts.Rows[j]["emp_email"], Dts.Rows[j]["emp_name"], "Aadhaar" });*/
                   
                    Dts.Rows[0]["date_pick"],
                    Dts.Rows[0]["emp_name"],
                    Dts.Rows[0]["surety_parent"],
                    Dts.Rows[0]["age"],
                    Dts.Rows[0]["perm_add1"],
                    Dts.Rows[0]["emp_post"],
                    Dts.Rows[0]["emp_district"],
                    Dts.Rows[0]["emp_state"],
                    Dts.Rows[0]["perm_pin"],
                        Dts1.Rows[0]["surety_name"],
                        Dts1.Rows[0]["surety_parentnm"],
                        Dts1.Rows[0]["age"],
                        Dts1.Rows[0]["surety_addr"],
                        Dts1.Rows[0]["surety_pin"],
                        Dts1.Rows[0]["surety_district"],
                        Dts1.Rows[0]["surety_state"],
            });

            //-----------------------------------------------------
            DataTable DATABANK2 = new DataTable("DATABANK");
            DATABANK2.Columns.Add("Surety2_name", typeof(String));
            DATABANK2.Columns.Add("Surety2_parent_name", typeof(String));
            DATABANK2.Columns.Add("Surety2_age", typeof(String));
            DATABANK2.Columns.Add("Surety2_address", typeof(String));
            DATABANK2.Columns.Add("Surety2_post", typeof(String));
            DATABANK2.Columns.Add("Surety2_district", typeof(String));
            DATABANK2.Columns.Add("Surety2_state", typeof(String));

            //-----------------------------------------------------
            DataTable DATABANK3 = new DataTable("DATABANK");
            DATABANK3.Columns.Add("Surety3_name", typeof(String));
            DATABANK3.Columns.Add("Surety3_parent_name", typeof(String));
            DATABANK3.Columns.Add("Surety3_age", typeof(String));
            DATABANK3.Columns.Add("Surety3_address", typeof(String));
            DATABANK3.Columns.Add("Surety3_post", typeof(String));
            DATABANK3.Columns.Add("Surety3_district", typeof(String));
            DATABANK3.Columns.Add("Surety3_state", typeof(String));

            //.Columns.Add("empolyee_NAME", typeof(String));
            //DATABANK3.Columns.Add("SURETY1_NAME", typeof(String));
            //-----------------------------------------------------
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    DATABANK1.Rows.Add(new Object[] { /*Dts.Rows[j]["emp_email"], Dts.Rows[j]["emp_name"], "Aadhaar" });*/
                   
                    Dts.Rows[j]["date_pick"],
                    Dts.Rows[j]["emp_name"],
                    Dts.Rows[j]["surety_parent"],
                    Dts.Rows[j]["age"],
                    Dts.Rows[j]["perm_add1"],
                    Dts.Rows[j]["emp_post"],
                    Dts.Rows[j]["emp_district"],
                    Dts.Rows[j]["emp_state"],
                    Dts.Rows[j]["perm_pin"]
                    //get_employee_details
                });
                }
            }
            if (Dts1.Rows.Count > 0)
            {
                for (int k = 0; k < Dts1.Rows.Count; k++)
                {

                    if (k == 0)
                    {
                        DATABANK2.Rows.Add(new Object[] { /*Dts1.Rows[k]["emg_email"], Dts1.Rows[k]["emg_cont_name"], "Aadhaar" });*/

                        Dts1.Rows[k]["surety_name"],
                        Dts1.Rows[k]["surety_parentnm"],
                        Dts1.Rows[k]["age"],
                        Dts1.Rows[k]["surety_addr"],
                        Dts1.Rows[k]["surety_pin"],
                        Dts1.Rows[k]["surety_district"],
                        Dts1.Rows[k]["surety_state"],
                        

                        //get_surety1_details_incorrectFormat
                    });
                        surety_eMail = Dts1.Rows[k]["surety_email"].ToString();

                    }
                    else if (k == 1)
                    {
                        DATABANK3.Rows.Add(new Object[] { /*Dts1.Rows[k]["emg_email"], Dts1.Rows[k]["emg_cont_name"], "Aadhaar" });*/

                        Dts1.Rows[k]["surety_name"],
                        Dts1.Rows[k]["surety_parentnm"],
                        Dts1.Rows[k]["age"],
                        Dts1.Rows[k]["surety_addr"],
                        Dts1.Rows[k]["surety_pin"],
                        Dts1.Rows[k]["surety_district"],
                        Dts1.Rows[k]["surety_state"],
                        

                        //get_surety2_details_incorrectFormat
                    });
                        surety2_eMail = Dts1.Rows[k]["surety_email"].ToString();
                        //get_surety2_details_incorrectFormat
                    }
                }
            }



            // DATABANK1.Merge(DATABANK2);
            // allList = DATABANK1;
            // employeeArray = JsonConvert.SerializeObject(DATABANK1);
            // suretyArray = JsonConvert.SerializeObject(allList);
            //dataFields += employeeArray;
            //dataFields += suretyArray;
            //dataFields += DATABANK1;
            //dataFields += DATABANK2;
            //DataTable d = new DataTable();
            tempArray1 = JsonConvert.SerializeObject(allList);
            string dataField = tempArray1.Substring(1, tempArray1.Length - 2);
            //if (Dts.Rows.Count > 0)
            //{
            //    for (int j = 0; j < Dts.Rows.Count; j++)
            //    {


            //          sgnnamearray = "[" + "\n" +
            //            @"        {" + "\n" +
            //            @"            ""identifier"": " + Dts.Rows[j]["emp_email"] + "," + "\n" +
            //            //                    @"            ""identifier"": ""jithinkarookaran@gmail.com""," + "\n" +
            //            @"            ""name"": "+ Dts.Rows[j]["emp_name"] + "," + "\n" +
            //            @"            ""sign_type"": ""Aadhaar""" + "\n" +
            //            @"        }," + "\n" +
            //            //@"        {" + "\n" +
            //            //@"            ""identifier"": ""lakshmicp68@gmail.com""," + "\n" +
            //            //@"            ""name"": ""Sreelakshmi.C P""," + "\n" +
            //            //@"            ""sign_type"": ""Aadhaar""" + "\n" +
            //            //@"        }" + "\n" +
            //            @"    ],";
            //    }

            //}
            //--------------------------------------------------------------------
            var client = new RestClient("https://ext.digio.in:444");
            var request = new RestRequest("/v2/client/template/multi_templates/create_sign_request", Method.Post);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", "Basic QUlQSTI4UjhQRDNROTlUVkM0NlNSMUZWRFZGQjRFR1U6WlhJT1NDWFJVQldJWDdWVUdVNUtPN0NNTDJaRUFCTFk=");

            //var body = @"{" + "\n" +
            //@"    ""signers"": 
            //" + sgnnamearray
            //+ ",\n" +
            //@"    ""expire_in_days"": 10," + "\n" +
            //@"    ""send_sign_link"": true," + "\n" +
            //@"    ""notify_signers"": true," + "\n" +
            //@"    ""display_on_page"": ""custom""," + "\n" +
            // @"    ""display_on_page"": ""custom""," + "\n" +
            //@"    ""sign_coordinates"": {" + "\n" +
            //@"        ""+emp_email+"": {" + "\n" +
            //@"            ""1"": [" + "\n" +
            //@"                {" + "\n" +
            //@"                    ""llx"": 374.03379055441474," + "\n" +
            //@"                    ""lly"": 325.35158283648883," + "\n" +
            //@"                    ""urx"": 514.0316226500211," + "\n" +
            //@"                    ""ury"": 365.3484905660377" + "\n" +
            //@"                }" + "\n" +
            //@"            ]" + "\n" +
            //@"        }," + "\n" +
            //@"        ""+emp_email+"": {" + "\n" +
            //@"            ""1"": [" + "\n" +
            //@"                {" + "\n" +
            //@"                    ""llx"": 388.7017823408624," + "\n" +
            //@"                    ""lly"": 251.42655380891264," + "\n" +
            //@"                    ""urx"": 528.6996144364688," + "\n" +
            //@"                    ""ury"": 291.42346153846154" + "\n" +
            //@"                }" + "\n" +
            //@"            ]" + "\n" +
            //@"        }" + "\n" +
            //@"    }," + "\n" +
            //@"    ""file_name"": ""printagreement.pdf""," + "\n" +
            //@"    ""estamp_request"": {" + "\n" +
            //@"        ""tags"": {" + "\n" +
            //@"            ""+stamp_tag+"": 1" + "\n" +
            //@"        }," + "\n" +
            //@"        ""sign_on_page"": ""LAST""," + "\n" +
            //@"        ""note_content"": ""This is dummy content""," + "\n" +
            //@"        ""note_on_page"": ""ALL""" + "\n" +
            //@"    }," + "\n" +
            //@"    ""callback"": ""7e373aa0-a409-6f58-be4e-58ead2f6ba339""," + "\n" +
            //@"    ""templates"": [" + "\n" +
            //@"        {" + "\n" +
            //@"            ""template_key"": ""+tempId+""," + "\n" +
            //@"            ""template_values"": {" + "\n" +
            //@"                ""NAME"": ""+name+""," + "\n" +
            //@"                ""MOB"": ""+mob+""" + "\n" +
            //@"            }" + "\n" +
            //@"         } ]" + "\n" +
            //@"        " + "\n" +
            //@" }" + "\n" +
            //@"" + "\n" +
            //@"";

            var body = @"{
" + "\n" +
     @"    ""signers"": 
" + sgnnamearray + ","
+ "\n" +
     @"    ""expire_in_days"": 10,
" + "\n" +
     @"    ""send_sign_link"": true,
" + "\n" +
     @"    ""notify_signers"": true,
" + "\n" +
     @"    ""display_on_page"": ""custom"",
" + "\n" +
     @"    ""sign_coordinates"": {
 """ + emp_eMail +
     @"""       :{
" + "\n" +
     @"            ""1"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 84.99963391655452,
" + "\n" +
     @"                    ""lly"": 5.003094333704176,
" + "\n" +
     @"                    ""urx"": 184.9953345935765,
" + "\n" +
     @"                    ""ury"": 35.99977546777544
" + "\n" +
     @"                }
" + "\n" +
     @"            ],
" + "\n" +
     @"            ""2"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 74.99999684625493,
" + "\n" +
     @"                    ""lly"": 0.9938143817417615,
" + "\n" +
     @"                    ""urx"": 213.0015786272688,
" + "\n" +
     @"                    ""ury"": 26.000113705583765
" + "\n" +
     @"                }
" + "\n" +
     @"            ],
" + "\n" +
     @"            ""3"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 107.00027858081471,
" + "\n" +
     @"                    ""lly"": 0.0021482521018503396,
" + "\n" +
     @"                    ""urx"": 223.0068488830486,
" + "\n" +
     @"                    ""ury"": 26.000113705583765
" + "\n" +
     @"                }
" + "\n" +
     @"            ],
" + "\n" +
     @"            ""4"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 349,
" + "\n" +
     @"                    ""lly"": 398,
" + "\n" +
     @"                    ""urx"": 456,
" + "\n" +
     @"                    ""ury"": 427
" + "\n" +
     @"                }
" + "\n" +
     @"            ]
" + "\n" +
     @"        },
""" + surety_eMail +
     @"""        : {
" + "\n" +
     @"            ""1"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 363.0000161507403,
" + "\n" +
     @"                    ""lly"": 5.998450709987341,
" + "\n" +
     @"                    ""urx"": 462.9957168277623,
" + "\n" +
     @"                    ""ury"": 40.00011642411643
" + "\n" +
     @"                }
" + "\n" +
     @"            ],
" + "\n" +
     @"            ""2"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 398.9998738501971,
" + "\n" +
     @"                    ""lly"": 0.1206042294574873,
" + "\n" +
     @"                    ""urx"": 522.0030251410305,
" + "\n" +
     @"                    ""ury"": 24.121827411167512
" + "\n" +
     @"                }
" + "\n" +
     @"            ],
" + "\n" +
     @"            ""3"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 396.0001892247043,
" + "\n" +
     @"                    ""lly"": 0.33502947037595177,
" + "\n" +
     @"                    ""urx"": 509.0043909458155,
" + "\n" +
     @"                    ""ury"": 27.338071065989844
" + "\n" +
     @"                }
" + "\n" +
     @"            ],
" + "\n" +
     @"            ""4"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 349,
" + "\n" +
     @"                    ""lly"": 365,
" + "\n" +
     @"                    ""urx"": 457,
" + "\n" +
     @"                    ""ury"": 395
" + "\n" +
     @"                }
" + "\n" +
     @"            ]
" + "\n" +
     @"        },
""" + surety2_eMail +
     @"""        : {
" + "\n" +
     @"            ""4"": [
" + "\n" +
     @"                {
" + "\n" +
     @"                    ""llx"": 350,
" + "\n" +
     @"                    ""lly"": 330,
" + "\n" +
     @"                    ""urx"": 458,
" + "\n" +
     @"                    ""ury"": 361
" + "\n" +
     @"                }
" + "\n" +
     @"            ]
" + "\n" +
     @"        }
" + "\n" +
     @"    },
" + "\n" +
     @"    ""file_name"": ""printagreement.pdf"",
" + "\n" +
     @"    ""templates"": [
" + "\n" +
     @"        {
" + "\n" +
     @"            ""template_key"": ""TMP221110093550858TTB32YAW2D8MT7"",
" + "\n" +
     @"            ""template_values"": 

" + dataField +
"\n" +

     //     @"                ""date"": ""+dates+"",
     //" + "\n" +
     //     @"                ""emp_name"": ""+name+"",
     //" + "\n" +
     //     @"                ""emp_parent/mother_name"": ""+emp_parent_nm+"",
     //" + "\n" +
     //     @"                ""emp_AGE"": ""+age+"",
     //" + "\n" +
     //     @"                ""emp_Address"": ""+emp_address+"",
     //" + "\n" +
     //     @"                ""emp_post"": ""+emp_post+"",
     //" + "\n" +
     //     @"                ""emp_district"": ""+emp_district+"",
     //" + "\n" +
     //     @"                ""emp_state"": ""+emp_state+"",
     //" + "\n" +
     //     @"                ""emp_pin"": ""emp_pin"",
     //" + "\n" +
     //     @"                ""Surety2_name"": ""+sur1_name+"",
     //" + "\n" +
     //     @"                ""Surety2_parent_name"": ""+sur1_parent+"",
     //" + "\n" +
     //     @"                ""Surety2_age"": ""sur1_age"",
     //" + "\n" +
     //     @"                ""Surety2_address"": ""+sur1_address+"",
     //" + "\n" +
     //     @"                ""Surety2_post"": ""+sur1_post+"",
     //" + "\n" +
     //     @"                ""Surety2_district"": ""+sur1_district+"",
     //" + "\n" +
     //     @"                ""Surety2_state"": ""+sur1_state+"",
     //" + "\n" +
     //     @"                ""Surety3_name"": ""+sur2_name+"",
     //" + "\n" +
     //     @"                ""Surety3_parent_name"": ""+sur2_parent_nm+"",
     //" + "\n" +
     //     @"                ""Surety3_age"": ""+sur2_age+"",
     //" + "\n" +
     //     @"                ""Surety3_address"": ""+sur2_address+"",
     //" + "\n" +
     //     @"                ""Surety3_post"": ""+sur2_post+"",
     //" + "\n" +
     //     @"                ""Surety3_district"": ""+sur2_district+"",
     //" + "\n" +
     //     @"                ""Surety3_state"": ""+sur2_state+"",
     //" + "\n" +
     //     @"                ""empolyee_NAME"": ""+name+"",
     //" + "\n" +
     //     @"                ""SURETY1_NAME"": ""+name+""
     //" + "\n" +
     //@"            }

     @"        }
" + "\n" +
     @"    ]
" + "\n" +
     @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            string dataString = response.Content;
            string jsonString = string.Empty;
            jsonString = JsonConvert.SerializeObject(response.Content);
            return jsonString;
            // return JsonConvert.DeserializeObject(dataString);
            //eStamp_list ci = new eStamp_list();
            //List<eStamp_list> state_list = new List<eStamp_list>();

            //dynamic jResults = JsonConvert.DeserializeObject(dataString);
            //List<string> counties = new List<string>();
            //foreach (var county in jResults.Everything)
            //{
            //    counties.Add((string)county.datalist_1);
            //}
            //return counties;
            //return jResults;
        }

    }


}