﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.Script.Services;


using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;

namespace E_STAMP_AND_E_SIGN.E_STAMP
{
    public partial class eStamp_generate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //string val = Decrypt("zmQ64Z4qNksDOSmfmqIMfQ==");
            //Session["userid"] = val;
            //Session["USER_NM"] = val;
           

        }

        [WebMethod]
        public static string emp_status(string empId)//request status
        {
            string val = Decrypt(empId);
            //string val = Decrypt("zmQ64Z4qNksDOSmfmqIMfQ==");
            HttpContext.Current.Session["userid"] = val;
            HttpContext.Current.Session["USER_NM"] = val;
            string res = "1";
            return res;
        }
        public class eStamp_list
        {
            public int state_id { get; set; }
            public int select_count { get; set; }
            public int stamp_paper { get; set; }
            public int tbl_id { get; set; }
            public string state_name { get; set; }
            public string state_nm { get; set; }
            public string document_id { get; set; }

            public string stateID { get; set; }
            public string t_userId { get; set; }
        }

        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "hyddhrii%2moi43Hd5%%";
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        [WebMethod]
        public static IList eStamp_stateListdb()
        {
            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string userid = HttpContext.Current.Session["userid"].ToString();
            DataTable Dts = new DataTable();
            Dts = servcon.eStamp_states_selection("1");
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    state_list.Add(new eStamp_list()
                    {
                        state_id = Convert.ToInt32(Dts.Rows[j]["state_id"]),
                        state_name = Convert.ToString(Dts.Rows[j]["state_name"]),
                        t_userId = userid,
                    });
                }
            }
            return state_list;
        }
        [WebMethod]
        public static string eStamp_insert_trackDb(string STATE_ID, int STAMP_PPR, int SELECTED_CNT)
        {

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            int COMP_ID = 0;
            string USER_ID = HttpContext.Current.Session["userid"].ToString();
            string USER_NM = HttpContext.Current.Session["USER_NM"].ToString();
            string Dts = servcon.eStamp_insert_track(USER_ID, USER_NM, STATE_ID, STAMP_PPR, 0, SELECTED_CNT, COMP_ID);
            return Dts;
        }
        [WebMethod]
        public static IList eStamp_fetch_stampDetailsDb()
        {
            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string user_id = HttpContext.Current.Session["userid"].ToString();
            //string user_id = "375522";
            DataTable Dts = new DataTable();
            Dts = servcon.eStamp_fetch_stampDetails(user_id);
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    state_list.Add(new eStamp_list()
                    {
                        stamp_paper = Convert.ToInt32(Dts.Rows[j]["stamp_paper"]),
                        select_count = Convert.ToInt32(Dts.Rows[j]["selected_cnt"]),
                        state_nm = Convert.ToString(Dts.Rows[j]["state_name"]),
                        stateID = Convert.ToString(Dts.Rows[j]["state_id"]),
                        tbl_id = Convert.ToInt32(Dts.Rows[j]["tab_id"]),
                        document_id = Convert.ToString(Dts.Rows[j]["document_id"])


                    });
                }
            }
            return state_list;
        }
        [WebMethod]
        public static string eStamp_delete_trackDb(int tbl_id)
        {

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string user_id = HttpContext.Current.Session["userid"].ToString();
            string Dts = servcon.eStamp_delete_track(tbl_id, user_id);
            return Dts;
        }
        //----------------------------------------------------------------------------------------
        [WebMethod]
        public static string eStamp_saveId(string documentId)//requsted document id
        {
            string document_id = documentId;
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string USER_ID = HttpContext.Current.Session["userid"].ToString();
            string Dts = servcon.eStamp_update_documentId(USER_ID, documentId);
            return Dts;

        }
        [WebMethod]
        public static string eStamp_getDocs(string document_id)//download
        {
            //// var document_id = "DID221110094005437KNOANCN4VT3TDA";
            var client = new RestClient("https://ext.digio.in:444");
            //client.Timeout = -1;
            var request = new RestRequest("/v2/client/document/download?document_id=" + document_id);

            request.AddHeader("authorization", "Basic QUlQSTI4UjhQRDNROTlUVkM0NlNSMUZWRFZGQjRFR1U6WlhJT1NDWFJVQldJWDdWVUdVNUtPN0NNTDJaRUFCTFk=");
            byte[] buffer = client.DownloadData(request);
            string temp_inBase64 = Convert.ToBase64String(buffer);

            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string USER_ID = HttpContext.Current.Session["userid"].ToString();
            int TYPE_CNT = 6;
            // //  string Dts = servcon.eStamp_update_download_details( USER_ID, buffer, TYPE_CNT);
            // //  return Dts;





            // //-------------------------------------------------
            // string result = "";
            // HRMSERVICE.IService obj;
            // obj = new HRMSERVICE.IService();
            // string final = USER_ID + "¿" + TYPE_CNT;
            // DataTable ds = new DataTable();

            // result = obj.EnrolDocumentUpload("47", final, buffer);

            // return result;
            // //-------------------------------------------------


            // //byte[] bytes = Convert.FromBase64String(temp_inBase64);
            // //File.WriteAllBytes(@"C:\temp\pdfFileName.pdf", bytes);

            // RestResponse response = client.Execute(request);
            // Console.WriteLine(response.Content);
            // string jsonString = string.Empty;
            // jsonString = JsonConvert.SerializeObject(response.Content);
            // Console.WriteLine(jsonString);
            // return jsonString;
            byte[] bytes = Convert.FromBase64String(temp_inBase64);
            //----------------------------------------------------------
            string subPath = USER_ID;
            string folderName = @"C:\agreement\" + USER_ID;
            // If directory does not exist, create it
            if (!Directory.Exists(folderName))
            {
                Directory.CreateDirectory(folderName);
                File.WriteAllBytes(@"C:\agreement\" + subPath + @"\pdf_" + USER_ID + "_File.pdf", bytes);
            }
            else
            {
                File.WriteAllBytes(@"C:\agreement\" + subPath + @"\pdf_" + USER_ID + "_File.pdf", bytes);
            }
            string result = "";
            //string InputString = upload_file.Split(',')[1];
            // Byte[] imgByte = Convert.FromBase64String(InputString);
            HRM_Service.ServiceClient obj;
            obj = new HRM_Service.ServiceClient();
            string final = USER_ID + "?" + TYPE_CNT;
            DataTable ds = new DataTable();

            result = obj.EnrolDocumentUpload("56", final, buffer);
            //string result1 = "";
            //result1 = temp_inBase64;
            //string result2 = "";
            //result2 = result+"~~~" + result1;

            return result;
        }
        [WebMethod]
        public static string eStamp_status(string documentId)//request status
        {
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string listData = "";
            string docId = documentId;
            var client = new RestClient("https://ext.digio.in:444");

            var request = new RestRequest("/v2/client/document/" + docId);
            request.AddHeader("authorization", "Basic QUlQSTI4UjhQRDNROTlUVkM0NlNSMUZWRFZGQjRFR1U6WlhJT1NDWFJVQldJWDdWVUdVNUtPN0NNTDJaRUFCTFk=");


            RestResponse response = client.Execute(request);
            string jsonString = string.Empty;


            //{"id":"DID221116095258938DRIH5SR1OLL96G","is_agreement":true,"agreement_type":"outbound","agreement_status":"requested","file_name":"printagreement.pdf","updated_at":"2022-11-16 09:52:59","created_at":"2022-11-16 09:52:59","self_signed":false,"self_sign_type":"aadhaar","no_of_pages":4,"signing_parties":[{"name":"RAMANKUTTY","status":"requested","updated_at":"2022-11-16 09:53:00","type":"self","signature_type":"aadhaar","identifier":"harishyampkd@gmail.com","expire_on":"2022-11-27 00:00:00"},{"name":"testuser","status":"requested","updated_at":"2022-11-16 09:53:00","type":"self","signature_type":"aadhaar","identifier":"1HARISHYAMPKD@GMAIL.COM","expire_on":"2022-11-27 00:00:00"},{"name":"HARISHYAM  N","status":"requested","updated_at":"2022-11-16 09:53:00","type":"self","signature_type":"aadhaar","identifier":"HARISHYAMHARI@OUTLOOK.COM","expire_on":"2022-11-27 00:00:00"}],"sign_request_details":{"name":"Mannapuram","requested_on":"2022-11-16 09:53:00","expire_on":"2022-11-27 00:00:00","identifier":"itchr@manappuram.com","requester_type":"org"},"channel":"api","other_doc_details":{},"attached_estamp_details":{}}

            dynamic data = JObject.Parse(response.Content);


            string agreement_status = data.agreement_status;
            string is_agreement = data.is_agreement;

            stampResponse datb = new stampResponse()
            {
                agreement_status = agreement_status,
                is_agreement = is_agreement

            };
            return JsonConvert.SerializeObject(datb);


        }

        class estamresponse
        {
         
            public string id { get; set; }
            public string send_sign_link { get; set; }
        }
        public class stampResponse
        {
            public string agreement_status { get; set; }

            public string is_agreement { get; set; }
        }
        public class eStampStatus
        {

            public List<eStamp_get_status> data { get; set; }
        }
        public class eStamp_get_status
        {

            public string id { get; set; }
            public string is_agreement { get; set; }
            public string agreement_type { get; set; }
            public string agreement_status { get; set; }
            public string file_name { get; set; }
            public string updated_at { get; set; }
            public string created_at { get; set; }
            public string self_signed { get; set; }
            public string self_sign_type { get; set; }
            public string no_of_pages { get; set; }
            public string signing_parties { get; set; }
            public string status { get; set; }
            public string type { get; set; }
            public string signature_type { get; set; }
            public string identifier { get; set; }
            public string expire_on { get; set; }
            public string name { get; set; }
            public string sign_request_details { get; set; }
            public string requested_on { get; set; }
            public string requester_type { get; set; }
            public string channel { get; set; }
            public string other_doc_details { get; set; }
            public string attached_estamp_details { get; set; }

        }
        //----------------------------------


        //-----------------------------------
        [WebMethod]
        public static string eStampGenerate(string state_id)
        {

            //---------------------------------------------------------------------
            string tempId = "";
            string stamp_tag = "";
            string mob = "";
            string name = "";
            string emp_eMail = "";
            string surety_eMail = "";
            string dates = "";
            string emp_parent_nm = "";
            string age = "";
            string template_name = "";
            string emp_address = "";
            string emp_post = "";
            string emp_district = "";
            string emp_state = "";
            string emp_pin = "";
            string sur1_name = "";
            string sur1_parent = "";
            string sur1_age = "";
            string sur1_address = "";
            string sur1_post = "";
            string sur1_district = "";
            string sur1_state = "";
            string sur2_name = "";
            string sur2_parent_nm = "";
            string sur2_age = "";
            string sur2_address = "";
            string sur2_post = "";
            string sur2_district = "";
            string sur2_state = "";
            string surety2_eMail = "";
            string content = "";

            eStamp_list ci = new eStamp_list();
            List<eStamp_list> state_list = new List<eStamp_list>();
            string sgnnamearray = "";
            string tempArray1 = "";
            //string tempArray2 = "";
            //string employeeArray = "";
            //string suretyArray = "";
            //string dataFields = "";
            int numberOfRecords = 0;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            DataSet dataSet = new DataSet();
            DataTable Dts = new DataTable();
            DataTable Dts1 = new DataTable();
            DataTable Dts2 = new DataTable();
            DataTable allList = new DataTable();
            HR_SERVICE.ServiceSoapClient servcon = new HR_SERVICE.ServiceSoapClient();
            string user_id = HttpContext.Current.Session["userid"].ToString();
            dataSet = servcon.eStamp_fetch_userDetails(user_id);
            Dts = dataSet.Tables[0];
            Dts1 = dataSet.Tables[1];
            DataTable DATABANK = new DataTable("DATABANK");
            DATABANK.Columns.Add("identifier", typeof(String));
            DATABANK.Columns.Add("name", typeof(String));
            DATABANK.Columns.Add("sign_type", typeof(String));
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    DATABANK.Rows.Add(new Object[] { Dts.Rows[j]["emp_email"], Dts.Rows[j]["emp_name"], "Aadhaar" });
                    mob = Dts.Rows[j]["cont_phone"].ToString();
                    name = Dts.Rows[j]["emp_name"].ToString();
                    emp_eMail = Dts.Rows[j]["emp_email"].ToString();
                    //surety_eMail= Dts.Rows[j]["surety_email"].ToString();
                    dates = Dts.Rows[j]["date_pick"].ToString();
                    emp_parent_nm = Dts.Rows[j]["surety_parent"].ToString();
                    age = Dts.Rows[j]["emg_email"].ToString();
                    emp_address = Dts.Rows[j]["perm_add1"].ToString();
                    emp_post = Dts.Rows[j]["emp_post"].ToString();
                    emp_district = Dts.Rows[j]["emp_district"].ToString();
                    emp_state = Dts.Rows[j]["emp_state"].ToString();
                    emp_pin = Dts.Rows[j]["perm_pin"].ToString();
                    content= Dts.Rows[j]["eStamp_content"].ToString();
                    numberOfRecords++;
                    //get_employee_details
                }
            }
            if (Dts1.Rows.Count > 0)
            {
                for (int k = 0; k < Dts1.Rows.Count; k++)
                {
                    DATABANK.Rows.Add(new Object[] { Dts1.Rows[k]["emg_email"], Dts1.Rows[k]["surety_name"], "Aadhaar" });
                    numberOfRecords++;
                    if (k == 0)
                    {
                        sur1_name = Dts1.Rows[k]["surety_name"].ToString();
                        sur1_parent = Dts1.Rows[k]["surety_parentnm"].ToString();
                        sur1_age = Dts1.Rows[k]["age"].ToString();
                        sur1_address = Dts1.Rows[k]["surety_addr"].ToString();
                        sur1_post = Dts1.Rows[k]["surety_pin"].ToString();
                        sur1_district = Dts1.Rows[k]["surety_district"].ToString();
                        sur1_state = Dts1.Rows[k]["surety_state"].ToString();
                        // sur1_state = Dts1.Rows[k]["surety_email"].ToString();
                        //get_surety1_details

                    }
                    else if (k == 1)
                    {
                        sur2_name = Dts1.Rows[k]["surety_name"].ToString();
                        sur2_parent_nm = Dts1.Rows[k]["surety_parentnm"].ToString();
                        sur2_age = Dts1.Rows[k]["age"].ToString();
                        sur2_address = Dts1.Rows[k]["surety_addr"].ToString();
                        sur2_post = Dts1.Rows[k]["surety_pin"].ToString();
                        sur2_district = Dts1.Rows[k]["surety_district"].ToString();
                        sur2_state = Dts1.Rows[k]["surety_state"].ToString();
                        //get_surety2_details
                    }
                }
            }
            sgnnamearray = JsonConvert.SerializeObject(DATABANK);
            Dts2 = servcon.eStamp_fetch_templateId(state_id);

            DataTable TEMPLATE1 = new DataTable("DATABANK");

            TEMPLATE1.Columns.Add("file_name", typeof(String));
            DataTable TEMPLATE2 = new DataTable("DATABANK");

            TEMPLATE2.Columns.Add("template_key", typeof(String));
            DataTable TEMPLATE3 = new DataTable("DATABANK");

            TEMPLATE3.Columns.Add("tags", typeof(String));
            if (Dts2.Rows.Count > 0)
            {
                for (int l = 0; l < Dts2.Rows.Count; l++)
                {
                    TEMPLATE1.Rows.Add(new Object[] {
                         Dts2.Rows[l]["template_name"],
                     });

                    TEMPLATE2.Rows.Add(new Object[] {
                         Dts2.Rows[l]["template_id"],
                     });

                    TEMPLATE3.Rows.Add(new Object[] {
                         Dts2.Rows[l]["stamp_tag"],
                     });

                    tempId = Convert.ToString(Dts2.Rows[l]["template_id"]);
                    stamp_tag = Convert.ToString(Dts2.Rows[l]["stamp_tag"]);
                    template_name = Convert.ToString(Dts2.Rows[l]["template_name"]);
                    //get_template_details
                }

            }
            string tempplateVal1 = "";
            string templateVal2 = "";
            string templateVal3 = "";
            tempplateVal1 = JsonConvert.SerializeObject(TEMPLATE1);
            templateVal2 = JsonConvert.SerializeObject(TEMPLATE2);
            templateVal3 = JsonConvert.SerializeObject(TEMPLATE3);
            //-----------------------------------------------------
            DataTable DATABANK1 = new DataTable("DATABANK");
            DATABANK1.Columns.Add("date", typeof(String));
            DATABANK1.Columns.Add("emp_name", typeof(String));
            DATABANK1.Columns.Add("emp_parent/mother_name", typeof(String));
            DATABANK1.Columns.Add("emp_AGE", typeof(String));
            DATABANK1.Columns.Add("emp_Address", typeof(String));
            DATABANK1.Columns.Add("emp_post", typeof(String));
            DATABANK1.Columns.Add("emp_district", typeof(String));
            DATABANK1.Columns.Add("emp_state", typeof(String));
            DATABANK1.Columns.Add("emp_pin", typeof(String));

            //
            allList.Columns.Add("date", typeof(String));
            allList.Columns.Add("emp_name", typeof(String));
            allList.Columns.Add("emp_parent/mother_name", typeof(String));
            allList.Columns.Add("age", typeof(String));
            allList.Columns.Add("emp_Address", typeof(String));
            allList.Columns.Add("emp_post", typeof(String));
            allList.Columns.Add("emp_district", typeof(String));
            allList.Columns.Add("emp_state", typeof(String));
            allList.Columns.Add("emp_pin", typeof(String));
            //
            allList.Columns.Add("Surety_name", typeof(String));
            allList.Columns.Add("Surety_parent_name", typeof(String));
            allList.Columns.Add("Surety_age", typeof(String));
            allList.Columns.Add("Surety_address", typeof(String));
            allList.Columns.Add("Surety_post", typeof(String));
            allList.Columns.Add("Surety_district", typeof(String));
            allList.Columns.Add("Surety_state", typeof(String));
            //
            allList.Columns.Add("Surety2_name", typeof(String));
            allList.Columns.Add("Surety2_parent_name", typeof(String));
            allList.Columns.Add("Surety2_age", typeof(String));
            allList.Columns.Add("Surety2_address", typeof(String));
            allList.Columns.Add("Surety2_post", typeof(String));
            allList.Columns.Add("Surety2_district", typeof(String));
            allList.Columns.Add("Surety2_state", typeof(String));

            allList.Rows.Add(new Object[] { /*Dts.Rows[j]["emp_email"], Dts.Rows[j]["emp_name"], "Aadhaar" });*/
                   
                    Dts.Rows[0]["date_pick"],
                    Dts.Rows[0]["emp_name"],
                    Dts.Rows[0]["father_name"],
                    Dts.Rows[0]["age"],
                    Dts.Rows[0]["perm_add1"],
                    Dts.Rows[0]["emp_post"],
                    Dts.Rows[0]["emp_district"],
                    Dts.Rows[0]["emp_state"],
                    Dts.Rows[0]["perm_pin"],
                        Dts1.Rows[0]["surety_name"],
                        Dts1.Rows[0]["surety_parentnm"],
                        Dts1.Rows[0]["age"],
                        Dts1.Rows[0]["surety_addr"],
                        Dts1.Rows[0]["surety_pin"],
                        Dts1.Rows[0]["surety_district"],
                        Dts1.Rows[0]["surety_state"],


                        Dts1.Rows[1]["surety_name"],
                        Dts1.Rows[1]["surety_parentnm"],
                        Dts1.Rows[1]["age"],
                        Dts1.Rows[1]["surety_addr"],
                        Dts1.Rows[1]["surety_pin"],
                        Dts1.Rows[1]["surety_district"],
                        Dts1.Rows[1]["surety_state"],
            });

            //-----------------------------------------------------
            DataTable DATABANK2 = new DataTable("DATABANK");
            DATABANK2.Columns.Add("Surety2_name", typeof(String));
            DATABANK2.Columns.Add("Surety2_parent_name", typeof(String));
            DATABANK2.Columns.Add("Surety2_age", typeof(String));
            DATABANK2.Columns.Add("Surety2_address", typeof(String));
            DATABANK2.Columns.Add("Surety2_post", typeof(String));
            DATABANK2.Columns.Add("Surety2_district", typeof(String));
            DATABANK2.Columns.Add("Surety2_state", typeof(String));

            //-----------------------------------------------------
            DataTable DATABANK3 = new DataTable("DATABANK");
            DATABANK3.Columns.Add("Surety3_name", typeof(String));
            DATABANK3.Columns.Add("Surety3_parent_name", typeof(String));
            DATABANK3.Columns.Add("Surety3_age", typeof(String));
            DATABANK3.Columns.Add("Surety3_address", typeof(String));
            DATABANK3.Columns.Add("Surety3_post", typeof(String));
            DATABANK3.Columns.Add("Surety3_district", typeof(String));
            DATABANK3.Columns.Add("Surety3_state", typeof(String));

            //.Columns.Add("empolyee_NAME", typeof(String));
            //DATABANK3.Columns.Add("SURETY1_NAME", typeof(String));
            //-----------------------------------------------------
            if (Dts.Rows.Count > 0)
            {
                for (int j = 0; j < Dts.Rows.Count; j++)
                {
                    DATABANK1.Rows.Add(new Object[] { /*Dts.Rows[j]["emp_email"], Dts.Rows[j]["emp_name"], "Aadhaar" });*/
                   
                    Dts.Rows[j]["date_pick"],
                    Dts.Rows[j]["emp_name"],
                    Dts.Rows[j]["surety_parent"],
                    Dts.Rows[j]["age"],
                    Dts.Rows[j]["perm_add1"],
                    Dts.Rows[j]["emp_post"],
                    Dts.Rows[j]["emp_district"],
                    Dts.Rows[j]["emp_state"],
                    Dts.Rows[j]["perm_pin"]
                    //get_employee_details
                });
                }
            }
            if (Dts1.Rows.Count > 0)
            {
                for (int k = 0; k < Dts1.Rows.Count; k++)
                {

                    if (k == 0)
                    {
                        DATABANK2.Rows.Add(new Object[] { /*Dts1.Rows[k]["emg_email"], Dts1.Rows[k]["emg_cont_name"], "Aadhaar" });*/

                        Dts1.Rows[k]["surety_name"],
                        Dts1.Rows[k]["surety_parentnm"],
                        Dts1.Rows[k]["age"],
                        Dts1.Rows[k]["surety_addr"],
                        Dts1.Rows[k]["surety_pin"],
                        Dts1.Rows[k]["surety_district"],
                        Dts1.Rows[k]["surety_state"],
                        

                        //get_surety1_details_incorrectFormat
                    });
                        surety_eMail = Dts1.Rows[k]["surety_email"].ToString();

                    }
                    else if (k == 1)
                    {
                        DATABANK3.Rows.Add(new Object[] { /*Dts1.Rows[k]["emg_email"], Dts1.Rows[k]["emg_cont_name"], "Aadhaar" });*/

                        Dts1.Rows[k]["surety_name"],
                        Dts1.Rows[k]["surety_parentnm"],
                        Dts1.Rows[k]["age"],
                        Dts1.Rows[k]["surety_addr"],
                        Dts1.Rows[k]["surety_pin"],
                        Dts1.Rows[k]["surety_district"],
                        Dts1.Rows[k]["surety_state"],
                        

                        //get_surety2_details_incorrectFormat
                    });
                        surety2_eMail = Dts1.Rows[k]["surety_email"].ToString();
                        //get_surety2_details_incorrectFormat
                    }
                }
            }



          
            tempArray1 = JsonConvert.SerializeObject(allList);
            string dataField = tempArray1.Substring(1, tempArray1.Length - 2);
            
            //--------------------------------------------------------------------
            var client = new RestClient("https://ext.digio.in:444");
            var request = new RestRequest("/v2/client/template/multi_templates/create_sign_request", Method.Post);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", "Basic QUlQSTI4UjhQRDNROTlUVkM0NlNSMUZWRFZGQjRFR1U6WlhJT1NDWFJVQldJWDdWVUdVNUtPN0NNTDJaRUFCTFk=");

            var body = @"{
" + "\n" +
     @"    ""signers"": 
" + sgnnamearray + ","
+ "\n" +
     @"    ""expire_in_days"": 10,
" + "\n" +
     @"    ""send_sign_link"": true,
" + "\n" +
     @"    ""notify_signers"": true,
" + "\n" +
     @"    ""display_on_page"": ""custom"",
" + "\n" +
     @"    ""sign_coordinates"": {
 """ + emp_eMail +
     @"""       :{
" + "\n" +
@"            ""1"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 53.000008884705885,
" + "\n" +
@"                    ""lly"": 34.99827787427854,
" + "\n" +
@"                    ""urx"": 193.0052610805354,
" + "\n" +
@"                    ""ury"": 75.9969384359401
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""2"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 56.99999898352942,
" + "\n" +
@"                    ""lly"": 35.99290714661757,
" + "\n" +
@"                    ""urx"": 196.0013775257227,
" + "\n" +
@"                    ""ury"": 74.99531980033274
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""3"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 52.00001136000001,
" + "\n" +
@"                    ""lly"": 71.99513273174269,
" + "\n" +
@"                    ""urx"": 192.99746711812847,
" + "\n" +
@"                    ""ury"": 110.99755607321133
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""4"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 56.99999898352942,
" + "\n" +
@"                    ""lly"": 61.007686945098044,
" + "\n" +
@"                    ""urx"": 197.00525117935894,
" + "\n" +
@"                    ""ury"": 101.00238269550752
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""5"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 45.00002868705883,
" + "\n" +
@"                    ""lly"": 87.00773482639615,
" + "\n" +
@"                    ""urx"": 185.0052915697852,
" + "\n" +
@"                    ""ury"": 127.00244126455911
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""6"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 404.00026065882355,
" + "\n" +
@"                    ""lly"": 568.0053268785423,
" + "\n" +
@"                    ""urx"": 544.005512854653,
" + "\n" +
@"                    ""ury"": 608.0000226289518
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""7"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 51.000013835294126,
" + "\n" +
@"                    ""lly"": 19.00040769680746,
" + "\n" +
@"                    ""urx"": 191.00527671802047,
" + "\n" +
@"                    ""ury"": 59.99905757071552
" + "\n" +
@"                }
" + "\n" +
@"            ]
" + "\n" +
 
     @"        },
""" + surety_eMail +
     @"""        : {
" + "\n" +
@"            ""1"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 230.00013105882354,
" + "\n" +
@"                    ""lly"": 34.0036635647943,
" + "\n" +
@"                    ""urx"": 370.00539394154987,
" + "\n" +
@"                    ""ury"": 75.00232412645585
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""2"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 240.00010630588238,
" + "\n" +
@"                    ""lly"": 33.99666351377264,
" + "\n" +
@"                    ""urx"": 380.0053585017119,
" + "\n" +
@"                    ""ury"": 72.99908685524127
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""3"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 225.00014343529412,
" + "\n" +
@"                    ""lly"": 70.99351409613531,
" + "\n" +
@"                    ""urx"": 365.0054063180205,
" + "\n" +
@"                    ""ury"": 109.99593743760396
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""4"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 224.00000583529413,
" + "\n" +
@"                    ""lly"": 61.007686945098044,
" + "\n" +
@"                    ""urx"": 364.0052580311236,
" + "\n" +
@"                    ""ury"": 101.00238269550752
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""5"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 221.00029341176474,
" + "\n" +
@"                    ""lly"": 87.00773482639615,
" + "\n" +
@"                    ""urx"": 361.0055562944911,
" + "\n" +
@"                    ""ury"": 127.00244126455911
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""6"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 404.999697882353,
" + "\n" +
@"                    ""lly"": 493.0013570090539,
" + "\n" +
@"                    ""urx"": 545.0049500781826,
" + "\n" +
@"                    ""ury"": 534.0000175707155
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""7"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 221.99973063529413,
" + "\n" +
@"                    ""lly"": 17.998789061200096,
" + "\n" +
@"                    ""urx"": 362.00498283112364,
" + "\n" +
@"                    ""ury"": 58.997438935108164
" + "\n" +
@"                }
" + "\n" +
@"            ]
" + "\n" +
 
     @"        },
""" + surety2_eMail +
     @"""        : {
" + "\n" +
 @"            ""1"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 399.9997102588236,
" + "\n" +
@"                    ""lly"": 34.0036635647943,
" + "\n" +
@"                    ""urx"": 540.9971660169521,
" + "\n" +
@"                    ""ury"": 75.00232412645585
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""2"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 411.000523482353,
" + "\n" +
@"                    ""lly"": 33.99666351377264,
" + "\n" +
@"                    ""urx"": 548.99802837091,
" + "\n" +
@"                    ""ury"": 72.99908685524127
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""3"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 393.99958503529416,
" + "\n" +
@"                    ""lly"": 69.99189546052796,
" + "\n" +
@"                    ""urx"": 534.9970407934227,
" + "\n" +
@"                    ""ury"": 108.9943188019966
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""4"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 390.9998726117647,
" + "\n" +
@"                    ""lly"": 61.007686945098044,
" + "\n" +
@"                    ""urx"": 531.9973283698932,
" + "\n" +
@"                    ""ury"": 101.00238269550752
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""5"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 394.0002854117647,
" + "\n" +
@"                    ""lly"": 87.00773482639615,
" + "\n" +
@"                    ""urx"": 534.0055482944911,
" + "\n" +
@"                    ""ury"": 127.00244126455911
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""6"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 405.999835482353,
" + "\n" +
@"                    ""lly"": 403.00511682862543,
" + "\n" +
@"                    ""urx"": 546.0050983650793,
" + "\n" +
@"                    ""ury"": 442.9998125790349
" + "\n" +
@"                }
" + "\n" +
@"            ],
" + "\n" +
@"            ""7"": [
" + "\n" +
@"                {
" + "\n" +
@"                    ""llx"": 390.9998726117647,
" + "\n" +
@"                    ""lly"": 19.00040769680746,
" + "\n" +
@"                    ""urx"": 531.9973283698932,
" + "\n" +
@"                    ""ury"": 59.99905757071552
" + "\n" +
@"                }
" + "\n" +
@"            ]
" + "\n" +
     @"        }
" + "\n" +
     @"    },
" + "\n" +
     @"    ""file_name"":""" + template_name +
     @""" ,
" + "\n" +
      @"     ""estamp_request"": {
" + "\n" +
      @"        ""tags"": {
" + "\n" +
      @" 
"""+ stamp_tag +
    @""": 1
" + "\n" +
      @"        },
" + "\n" +
      @"        ""sign_on_page"": ""LAST"",
" + "\n" +
      @"        ""note_content"": """+ content +
      @""",
" + "\n" +
      @"        ""note_on_page"": ""ALL""
" + "\n" +
      @"    },
" + "\n" +
@"
""templates"": [
" + "\n" +
     @"        {
" + "\n" +
     @"            ""template_key"": """+ tempId +
    @""" ,

             ""template_values"": 

" + dataField +
"\n" +

   

     @"        }
" + "\n" +
     @"    ]
" + "\n" +
     @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
            string dataString = response.Content;
           
            string jsonString = string.Empty;
            dynamic data = JObject.Parse(response.Content);
            string id = data.id;
            string send_sign_link = data.is_agreement;
           // string d_alert = "Hello";
            estamresponse datb = new estamresponse()
            {
                id = id,

                send_sign_link = send_sign_link

            };
            return JsonConvert.SerializeObject(datb);
           // return d_alert;
        }

    }
}