var loadFile1 = function(event) {
    var output1 = document.getElementById('output1');
    $('#output1').hide();
    $('.upfilestat1').hide();
    $('#spinner1').show();
    $('#uptext1').show();
    // $('.upfilestat1').show();
    $('.upbt1').addClass('bg2');
    $('#uptext1').html('Uploading...');
    setTimeout(() => {
      $('#spinner1').hide();
      $('#output1').show();
      $('.upfilestat1').addClass('co3');
      $('.upfilestat1').addClass('pointer');
      $('#uptext1').hide();
      $('.upbt1').addClass('bg3');
      $('#SuccessPopup').modal('show')
    }, 2000);
    output1.src = URL.createObjectURL(event.target.files[0]);
    output1.onload = function() {
      URL.revokeObjectURL(output1.src) // free memory
    }
  };

  var loadFile2 = function(event) {
    var output2 = document.getElementById('output2');
    $('#spinner2').show();
    $('.upfilestat2').hide();
    $('.upbt2').addClass('bg2');
    $('#uptext2').html('Uploading...');
    setTimeout(() => {
      $('#spinner2').hide();
      $('.upfilestat2').show();
      $('.upfilestat2').addClass('co3');
      $('.upfilestat2').addClass('pointer');
      $('#uptext2').html('View Document');
      $('.upbt2').addClass('bg3');
      $('#SuccessPopup').modal('show')
    }, 2000);
    output2.src = URL.createObjectURL(event.target.files[0]);
    output2.onload = function() {
      URL.revokeObjectURL(output2.src) // free memory
    }
  };

  var loadFile3 = function(event) {
    var output3 = document.getElementById('output3');

    $('#spinner3').show();
    $('.upfilestat3').hide();
    $('.upbt3').addClass('bg2');
    $('#uptext3').html('Uploading...');
    setTimeout(() => {
      $('#spinner3').hide();
      $('.upfilestat3').show();
      $('.upfilestat3').addClass('co3');
      $('.upfilestat3').addClass('pointer');
      $('#uptext3').html('View Document');
      $('.upbt3').addClass('bg3');
      $('#SuccessPopup').modal('show')
    }, 2000);

    // $('.upfilestat3').addClass('co3');
    // $('.upfilestat3').addClass('pointer');
    // $('#uptext3').html('View Document');
    output3.src = URL.createObjectURL(event.target.files[0]);
    output3.onload = function() {
      URL.revokeObjectURL(output3.src) // free memory
    }
  };

  var loadFile4 = function(event) {
    var output4 = document.getElementById('output4');
    $('#spinner4').show();
    $('.upfilestat4').hide();
    $('.upbt4').addClass('bg2');
    $('#uptext4').html('Uploading...');
    setTimeout(() => {
      $('#spinner4').hide();
      $('.upfilestat4').show();
      $('.upfilestat4').addClass('co3');
      $('.upfilestat4').addClass('pointer');
      $('#uptext4').html('View Document');
      $('.upbt4').addClass('bg3');
      $('#SuccessPopup').modal('show')
    }, 2000);
    // $('.upfilestat4').addClass('co3');
    // $('.upfilestat4').addClass('pointer');
    // $('#uptext4').html('View Document');
    output4.src = URL.createObjectURL(event.target.files[0]);
    output4.onload = function() {
      URL.revokeObjectURL(output4.src) // free memory
    }
  };

  var loadFile5 = function(event) {
    var output5 = document.getElementById('output5');
    $('#spinner5').show();
    $('.upbt5').addClass('bg2');
    $('.upfilestat5').hide();
    $('#uptext5').html('Uploading...');
    setTimeout(() => {
      $('#spinner5').hide();
      $('.upfilestat5').show();
      $('.upfilestat5').addClass('co3');
      $('.upfilestat5').addClass('pointer');
      $('#uptext5').html('View Document');
      $('.upbt5').addClass('bg3');
      $('#SuccessPopup').modal('show')
    }, 2000);
    // $('.upfilestat5').addClass('co3');
    // $('.upfilestat5').addClass('pointer');
    // $('#uptext5').html('View Document');
    output5.src = URL.createObjectURL(event.target.files[0]);
    output5.onload = function() {
      URL.revokeObjectURL(output5.src) // free memory
    }
  };

  var loadFile6 = function(event) {
    var output6 = document.getElementById('output6');
    $('#spinner6').show();
    $('.upfilestat6').hide();
    $('.upbt6').addClass('bg2');
    $('#uptext6').html('Uploading...');
    setTimeout(() => {
      $('#spinner6').hide();
      $('.upfilestat6').show();
      $('.upfilestat6').addClass('co3');
      $('.upfilestat6').addClass('pointer');
      $('#uptext6').html('View Document');
      $('.upbt6').addClass('bg3');
      $('#SuccessPopup').modal('show')
    }, 2000);
    // $('.upfilestat6').addClass('co3');
    // $('.upfilestat6').addClass('pointer');
    // $('#uptext6').html('View Document');
    output6.src = URL.createObjectURL(event.target.files[0]);
    output6.onload = function() {
      URL.revokeObjectURL(output6.src) // free memory
    }
  };