const searchlist=(id)=>{
    var searchkey = $('#searchkey'+id).val().length;
    if(searchkey>=2){
        $('#suggestion'+id).fadeIn();
    }
    else{
        $('#suggestion'+id).fadeOut();
    }
}